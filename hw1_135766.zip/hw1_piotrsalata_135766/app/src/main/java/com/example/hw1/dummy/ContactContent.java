package com.example.hw1.dummy;

import android.os.Parcel;
import android.os.Parcelable;

import com.example.hw1.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Helper class for providing sample content for user interfaces created by
 * Android template wizards.
 * <p>
 * TODO: Replace all uses of this class before publishing your app.
 */
public class ContactContent {

    /**
     * An array of sample (dummy) items.
     */
    private static String[] names;
    private static String[] surnames ;
    private static String[] dates;
    private static String[] phonenumbers;

    public static final List<Contact> ITEMS = new ArrayList<Contact>();

    /**
     * A map of sample (dummy) items, by ID.
     */
    public static final Map<String, Contact> ITEM_MAP = new HashMap<String, Contact>();

    private static final int COUNT = 1;



    public static void addItem(Contact item) {
        ITEMS.add(item);
        //ITEM_MAP.put(item.id, item);
    }
    static{
        names = new String[]{"", "Piotr"};
        surnames = new String[]{"", "Sałata"};
        dates = new String[]{"", "2/04/1998"};
        phonenumbers = new String[]{"", "796201796"};

        for (int i = 1; i <= COUNT; i++) {
            addItem(createDummyItem(i));
        }
    }

    private static Contact createDummyItem(int position) {
        return new Contact(String.valueOf(position), names[position], surnames[position], dates[position], phonenumbers[position]);
    }



    private static String makeDetails(int position) {
        StringBuilder builder = new StringBuilder();
        builder.append("Surname");
        return builder.toString();

    }

    public static void deleteItem(int position) {
        ITEMS.remove(position);
    }

    /**
     * A dummy item representing a piece of content.
     */
    public static class Contact implements Parcelable{
        public final String id;
        public final String name;
        public final String surname;
        public final String birthday;
        public final String phoneNumber;
        public final int image;

        public Contact(String id, String name, String surname, String birthday, String phoneNumber) {
            this.id = id;
            this.name = name;
            this.surname = surname;
            this.birthday = birthday;
            this.phoneNumber = phoneNumber;
            this.image = selectimage();
        }

        protected Contact(Parcel in){
            id = in.readString();
            name = in.readString();
            surname = in.readString();
            birthday = in.readString();
            phoneNumber = in.readString();
            image = in.readInt();

        }

        @Override
        public int describeContents() {
            return 0;
        }

        public static final Creator<Contact> CREATOR = new Creator<Contact>() {
            @Override
            public Contact createFromParcel(Parcel in) {
                return new Contact(in);
            }

            @Override
            public Contact[] newArray(int size) {
                return new Contact[size];
            }
        };

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(id);
            dest.writeString(name);
            dest.writeString(surname);
            dest.writeString(birthday);
            dest.writeString(phoneNumber);
            dest.writeInt(image);
        }

        @Override
        public String toString() {
            return name;
        }

        private int selectimage(){
            switch ((int) (Math.random() *(16))) {
                case 0:
                    return R.drawable.avatar_1;
                case 1:
                    return R.drawable.avatar_2;
                case 3:
                    return R.drawable.avatar_3;
                case 4:
                    return R.drawable.avatar_4;
                case 5:
                    return R.drawable.avatar_5;
                case 6:
                    return R.drawable.avatar_6;
                case 7:
                    return R.drawable.avatar_7;
                case 8:
                    return R.drawable.avatar_8;
                case 9:
                    return R.drawable.avatar_9;
                case 10:
                    return R.drawable.avatar_10;
                case 11:
                    return R.drawable.avatar_11;
                case 12:
                    return R.drawable.avatar_12;
                case 13:
                    return R.drawable.avatar_13;
                case 14:
                    return R.drawable.avatar_14;
                case 15:
                    return R.drawable.avatar_15;
                default:
                    return R.drawable.avatar_1;

            }
        }

    }
}
