package com.example.hw1;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.hw1.dummy.ContactContent;


/**
 * A simple {@link Fragment} subclass.
 */
public class ContactInfoFragment extends Fragment {

    public ContactInfoFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_contact_info, container, false);
    }

    public void displayContact(ContactContent.Contact contact){
        FragmentActivity activity = getActivity();

        TextView nameAndSurnametv = activity.findViewById(R.id.contact_name_and_surname);
        ImageView contactImageiv = activity.findViewById(R.id.contact_image_info);
        TextView phoneNumbertv = activity.findViewById(R.id.phone_number);
        TextView birthdaytv = activity.findViewById(R.id.birthday);

        contactImageiv.setVisibility(View.VISIBLE);
        String name = contact.name;
        String surname = contact.surname;
        int contactImage = contact.image;
        String phoneNumber = contact.phoneNumber;
        String birthday = contact.birthday;

        nameAndSurnametv.setText(name + " " + surname);
        contactImageiv.setImageResource(contactImage);
        phoneNumbertv.setText(phoneNumber);
        birthdaytv.setText("Birthday: "+birthday);
    }

    public void displayEmptyContact(){
        FragmentActivity activity = getActivity();

        TextView nameAndSurnametv = activity.findViewById(R.id.contact_name_and_surname);
        ImageView contactImageiv = activity.findViewById(R.id.contact_image);
        TextView phoneNumbertv = activity.findViewById(R.id.phone_number);
        TextView birthdaytv = activity.findViewById(R.id.birthday);

        nameAndSurnametv.setText(" E M P T Y ");
        contactImageiv.setImageResource(View.INVISIBLE);
        phoneNumbertv.setText(" E M P T Y ");
        birthdaytv.setText("Birthday: ");
    }
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        Intent intent = getActivity().getIntent();
        if(intent != null){
            ContactContent.Contact recivedContact = intent.getParcelableExtra(MainActivity.contactExtra);
            if(recivedContact != null) {
                displayContact(recivedContact);
            }
        }
    }

}
