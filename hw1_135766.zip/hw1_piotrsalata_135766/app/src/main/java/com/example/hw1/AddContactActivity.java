package com.example.hw1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.hw1.dummy.ContactContent;

import static com.example.hw1.dummy.ContactContent.ITEMS;

public class AddContactActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);

        add();
    }

    private void add(){
        Button addButton;

        addButton = findViewById(R.id.add_button);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText name;
                EditText surname;
                EditText birthday;
                EditText phoneNumber;

                name = findViewById(R.id.add_name);
                surname = findViewById(R.id.add_surname);
                birthday = findViewById(R.id. add_birthday);
                phoneNumber = findViewById(R.id. add_number);

                String nameS;
                String surnameS;
                String birthdayS;
                String phoneNumberS;

                nameS = name.getText().toString();
                surnameS = surname.getText().toString();
                birthdayS = birthday.getText().toString();
                phoneNumberS = phoneNumber.getText().toString();

                if(nameS.isEmpty()){
                    name.setError("!");
                    return;
                }
                if(surnameS.isEmpty()){
                    surname.setError("!");
                    return;
                }
                if(birthdayS.isEmpty()){
                    birthday.setError("!");

                    //elseif???


                }else if(check(birthdayS) == false){
                        birthday.setError("bad format - (dd/mm/yyyy)");
                        return;
                    }

                if(phoneNumberS.isEmpty()){
                    phoneNumber.setError("!");
                    return;

                    //elseif???

                }else if(!phoneNumberS.matches("([0-9]{9})")){
                        phoneNumber.setError("number format (9 digits)");
                        return;

                }
                ContactContent.Contact newContact = new ContactContent.Contact(String.valueOf(ITEMS.size()+1), nameS, surnameS, birthdayS, phoneNumberS);
                ContactContent.addItem(newContact);
                name.setText("");
                surname.setText("");
                birthday.setText("");
                phoneNumber.setText("");

                finish();
            }
        });
    }


    private boolean check(String bday){
        boolean result = false;
        if(bday.matches("([0-31]{2})/([0-12]{2})/([0-9]{4})")){
            result = true;
        }
        return result;
    }
}
