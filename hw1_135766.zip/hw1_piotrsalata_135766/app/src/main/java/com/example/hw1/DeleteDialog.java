package com.example.hw1;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * A simple {@link DialogFragment} subclass.
 */
public class DeleteDialog extends DialogFragment {

    public DeleteDialog() {
        // Required empty public constructor
    }

    static DeleteDialog newInstance() {return new DeleteDialog();}

   // public void show(FragmentManager supportFragmentManager, String string) {
  //  }

    public interface OnDeleteDialogInteractionListener {

        void onDialogPositiveClick(DialogFragment dialog);
        void onDialogNegativeClick(DialogFragment dialog);
    }
    @NonNull
    @Override
    public Dialog onCreateDialog(@NonNull Bundle savedInstanceState){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage(getString(R.string.question_delete));
        builder.setPositiveButton(getString(R.string.yes), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                OnDeleteDialogInteractionListener mListener =  (OnDeleteDialogInteractionListener) getActivity();
                mListener.onDialogPositiveClick(DeleteDialog.this);
            }
        });

        builder.setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                OnDeleteDialogInteractionListener mListener =  (OnDeleteDialogInteractionListener) getActivity();
                mListener.onDialogNegativeClick(DeleteDialog.this);
            }
        });
        return builder.create();

    }


/*
    @NonNull
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        TextView textView = new TextView(getActivity());
        textView.setText(R.string.hello_blank_fragment);
        return textView;
    }

 */
}
