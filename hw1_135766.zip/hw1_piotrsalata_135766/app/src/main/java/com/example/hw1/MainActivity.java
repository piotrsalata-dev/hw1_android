package com.example.hw1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.example.hw1.dummy.ContactContent;

public class MainActivity extends AppCompatActivity implements
        ContactFragment.OnListFragmentInteractionListener,
        DeleteDialog.OnDeleteDialogInteractionListener,
        CallDialog.OnCallDialogInteractionListener
{

    int selectedDeleteItem = -1;
    public static final String contactExtra = "contactExtra";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AddContactActivity.class);
                startActivity(intent);
            }
        });
    }

    public void startSecondActivity(ContactContent.Contact contact){
        Intent intent = new Intent(this, ContactInfoActivity.class);
        intent.putExtra(contactExtra, contact);
        startActivity(intent);
    }

    @Override
    public void onListFragmentClickInteraction(ContactContent.Contact item, View view) {

        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            displayContactInFragment(item);
        } else {
            startSecondActivity(item);
        }
    }

    @Override
    public void onListFragmentLongClickInteraction(ContactContent.Contact item) {
        CallDialog.newInstance(item.name).show(getSupportFragmentManager(), getString(R.string.callingdialog));
    }

    @Override
    public void onDeleteButtonClick(int position) {
        selectedDeleteItem = position;
        DeleteDialog.newInstance().show(getSupportFragmentManager(), getString(R.string.delete_dialog_tag));
    }

    @Override
    public void onDialogPositiveClick(DialogFragment dialog) {
        if (selectedDeleteItem >= 0 && selectedDeleteItem < ContactContent.ITEMS.size()) {
            ContactContent.deleteItem(selectedDeleteItem);
            ((ContactFragment) getSupportFragmentManager().findFragmentById(R.id.ContactListFragment)).notifyDataChange();


            ContactInfoFragment contactInfoFragment = ( (ContactInfoFragment) getSupportFragmentManager().findFragmentById(R.id.ContactInfoFragment));
            if(contactInfoFragment != null){
                contactInfoFragment.displayEmptyContact();
            }
        }
    }
    public void displayContactInFragment(ContactContent.Contact contact){
        ContactInfoFragment contactInfoFragment = ( (ContactInfoFragment) getSupportFragmentManager().findFragmentById(R.id.ContactInfoFragment));
        if(contactInfoFragment != null){
            contactInfoFragment.displayContact(contact);
        }
    }
    @Override
    public void onCallDialogPositiveClick(DialogFragment dialog) {
        Toast.makeText(getApplicationContext(), getString(R.string.calling), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDialogNegativeClick(DialogFragment dialog) {

    }

    @Override
    public void onCallDialogNegativeClick(DialogFragment dialog) {

    }

    @Override
    public void onCallDialogPositiveClick(CallDialog dialog) {

    }

    @Override
    public void onCallDialogNegativeClick(CallDialog dialog) {

    }

}
